import cv2
import numpy as np
from matplotlib import pyplot as plt

fname = 'terrain.jpg'
#fname = 'crayfish.jpg'
#fname = 'branches.jpg'
#fname = 'train.jpg'
#fname = 'map.jpg'

I = cv2.imread(fname, cv2.IMREAD_GRAYSCALE)

f, axes = plt.subplots(2, 3)

axes[0,0].imshow(I, 'gray', vmin=0, vmax=255)
axes[0,0].axis('off')
axes[1,0].hist(I.ravel(),256,[0,256]);


J=(I-100) * 255.0 / (200-100)
J[J<0]=0
J[J>255]=255
J=J.astype(np.uint8)

axes[0,1].imshow(J, 'gray', vmin=0, vmax=255)
axes[0,1].axis('off')
axes[1,1].hist(J.ravel(),256,[0,256]);

K = cv2.equalizeHist(I)

axes[0,2].imshow(K, 'gray', vmin=0, vmax=255)
axes[0,2].axis('off')
axes[1,2].hist(K.ravel(),256,[0,256]);


plt.show()


